#include <EEPROM.h>
#include <Arduino.h>
#include <SoftwareSerial.h>

// ===================
// Pin-definities
// ===================
const uint8_t NUM_SENSORS = 8;
const uint8_t sensorPins[NUM_SENSORS] = {A7, A6, A5, A4, A3, A2, A1, A0};
const byte buttonPin = 2;     // knop met interrupt (naar GND)
const byte ledPin    = 13;    // LED als status
const byte btRxPin   = 10;    // Arduino RX
const byte btTxPin   = 11;    // Arduino TX
// DRV8833 Motor Driver
#define MotorRight1 5 // Pinnen omgedraaid om draairichting te corrigeren
#define MotorRight2 3 // Pinnen omgedraaid om draairichting te corrigeren
#define MotorLeft1 6  // Was MotorRight1
#define MotorLeft2 9  // Was MotorRight2
const int SleepPin = 4; // nSLEEP pin op de DRV8833, moet hoog zijn om te werken

SoftwareSerial BT(btRxPin, btTxPin);   // RX, TX

// ===================
// Variabelen
// ===================
uint16_t whiteCal[NUM_SENSORS];
uint16_t blackCal[NUM_SENSORS];
bool calibrated = false;
int eepromBase = 0;
float lastBlackPos = (NUM_SENSORS - 1) / 2.0;
volatile bool buttonPressed = false;   // ISR zet deze
bool running = false;                  // systeemstatus
char inkomend;                        // inkomend BT-karakter
bool debug_output = true;             // Visuele output staat standaard aan
char bt_buffer[32];                   // Buffer voor inkomende BT commando's
uint8_t bt_buf_pos = 0;               // Huidige positie in de buffer

// ===================
// Lap Timer Variabelen
// ===================
unsigned long lapStartTime = 0;
unsigned long lastLapTime = 0;
int blackLinePasses = 0; // Telt het aantal passages over een zwarte lijn
enum LapDetectionState { ON_LINE, ON_FINISH_LINE };
LapDetectionState lapDetectionState = ON_LINE;
const int FINISH_LINE_THRESHOLD = 600; // Drempelwaarde om 'zwart' te detecteren op alle sensoren

// ===================
// PID Variabelen
// ===================
struct PidSettings {
  float Kp;
  float Ki;
  float Kd;
  int baseSpeed;
  unsigned long cycleTime;
};

PidSettings pid_settings = {0.8, 0.0, 4.0, 150, 30};

float integral = 0;
float lastError = 0;

// ===================
// Sensorfuncties
// ===================
void readSensors(uint16_t *buf) {
  for (uint8_t i = 0; i < NUM_SENSORS; i++) {
    buf[i] = analogRead(sensorPins[i]);
  }
}

void storeCalibration() {
  EEPROM.put(eepromBase, whiteCal);
  EEPROM.put(eepromBase + sizeof(whiteCal), blackCal);
  Serial.println("Kalibratie opgeslagen!");
  BT.println("Kalibratie opgeslagen!");
}

void saveSettings() {
  int addr = eepromBase + sizeof(whiteCal) + sizeof(blackCal);
  EEPROM.put(addr, pid_settings);
  BT.println("Instellingen opgeslagen in EEPROM.");
}

void loadSettings() {
  int addr = eepromBase + sizeof(whiteCal) + sizeof(blackCal);
  EEPROM.get(addr, pid_settings);
}

bool loadCalibration() {
  EEPROM.get(eepromBase, whiteCal);
  EEPROM.get(eepromBase + sizeof(whiteCal), blackCal);
  for (uint8_t i = 0; i < NUM_SENSORS; i++) {
    if (blackCal[i] <= whiteCal[i] + 200) return false;
    if (whiteCal[i] > 500 || blackCal[i] < 600) return false;
  }
  return true;
}

float calcLinePosition(uint16_t *raw) {
  readSensors(raw);

  uint16_t maxVal = 0;
  int peakIdx = -1;
  for (uint8_t i = 0; i < NUM_SENSORS; i++) {
    if (raw[i] > maxVal) {
      maxVal = raw[i];
      peakIdx = i;
    }
  }

  if (maxVal < 500) return lastBlackPos;

  float weightedSum = 0;
  float sumVal      = 0;
  uint16_t threshold = maxVal * 0.7;

  for (int8_t i = peakIdx - 1; i <= peakIdx + 1; i++) {
    if (i < 0 || i >= NUM_SENSORS) continue;
    if (raw[i] >= threshold) {
      weightedSum += raw[i] * i;
      sumVal      += raw[i];
    }
  }

  if (sumVal > 0) {
    float newPos = weightedSum / sumVal;
    float diff   = newPos - lastBlackPos;
    if (abs(diff) > 1.5) {
      newPos = lastBlackPos + (diff > 0 ? 1.5 : -1.5);
    }
    lastBlackPos = newPos;
  }

  return lastBlackPos;
}

void showLineASCII(float pos) {
  const int BAR_WIDTH = 40;
  int xPos = (int)(pos / 7.0 * (BAR_WIDTH - 1) + 0.5);
  xPos = constrain(xPos, 0, BAR_WIDTH - 1);
  String line = "";
  for (int i = 0; i < BAR_WIDTH; i++) {
    line += (i == xPos ? 'X' : '-'); // Bouw de visuele lijn
  }
  Serial.println(line); // Stuur alleen de lijn naar Serial
  BT.print(line);       // Stuur de lijn naar BT, maar ZONDER newline
}

void showSensorData(uint16_t *raw) {
  String line = "Raw:  ";
  for (uint8_t i = 0; i < NUM_SENSORS; i++) {
    line += raw[i];
    line += " ";
  }
  Serial.println(line);
  BT.println(line);
}

void waitForBluetoothConfirm() {
  while (!BT.available());
  while (BT.available()) BT.read(); // Leeg buffer na bevestiging
}

void calibrate() {
  uint16_t tmp[NUM_SENSORS];
  Serial.println(">>> Plaats op WIT en stuur 'k' via Bluetooth");
  BT.println(">>> Plaats op WIT en stuur 'k' via Bluetooth");
  waitForBluetoothConfirm();
  readSensors(tmp);
  for (int i = 0; i < NUM_SENSORS; i++) whiteCal[i] = tmp[i];

  delay(500);
  Serial.println(">>> Plaats op ZWART en stuur 'k' via Bluetooth");
  BT.println(">>> Plaats op ZWART en stuur 'k' via Bluetooth");
  waitForBluetoothConfirm();
  readSensors(tmp);
  for (int i = 0; i < NUM_SENSORS; i++) blackCal[i] = tmp[i];

  Serial.print("Wit:   ");
  BT.print("Wit:   ");
  for (int i = 0; i < NUM_SENSORS; i++) {
    Serial.print(whiteCal[i]); Serial.print(" ");
    BT.print(whiteCal[i]); BT.print(" ");
  }
  Serial.println();
  BT.println();
  Serial.print("Zwart: ");
  BT.print("Zwart: ");
  for (int i = 0; i < NUM_SENSORS; i++) {
    Serial.print(blackCal[i]); Serial.print(" ");
    BT.print(blackCal[i]); BT.print(" ");
  }
  Serial.println();
  BT.println();

  storeCalibration();
}

void checkLap(uint16_t *raw_values) {
  bool all_black = true;
  for (uint8_t i = 0; i < NUM_SENSORS; i++) {
    if (raw_values[i] < FINISH_LINE_THRESHOLD) {
      all_black = false;
      break;
    }
  }

  // State machine voor rondedetectie
  switch (lapDetectionState) {
    case ON_LINE:
      if (all_black) {
        // We komen op een brede zwarte lijn (finish of kruispunt)
        lapDetectionState = ON_FINISH_LINE;
        blackLinePasses++;

        // De eerste passage start de timer. Een ronde is voltooid bij elke 2e passage daarna (dus bij de 3e, 5e, 7e... totaal).
        if (blackLinePasses > 1 && (blackLinePasses - 1) % 2 == 0) {
          lastLapTime = millis() - lapStartTime; // Bereken tijd sinds de VORIGE finish
          BT.println(lastLapTime / 1000.0, 3);
          lapStartTime = millis(); // Reset de timer voor de volgende ronde
        } else if (blackLinePasses == 1) {
          // Dit is de allereerste start, dus start de timer
          lapStartTime = millis();
        }
      }
      break;
    case ON_FINISH_LINE:
      if (!all_black) {
        // We hebben de finishlijn verlaten
        lapDetectionState = ON_LINE;
      }
      break;
  }
}

void stopMotors() {
  digitalWrite(MotorLeft1, LOW);
  digitalWrite(MotorLeft2, LOW);
  digitalWrite(MotorRight1, LOW);
  digitalWrite(MotorRight2, LOW);
}

// ===================
// Knop- en Bluetooth-functies
// ===================
void updateState(bool newState) {
  if (newState == false) {
    stopMotors();
  }
  running = newState;
  digitalWrite(ledPin, running ? HIGH : LOW);
  Serial.print("Status: ");
  Serial.println(running ? "GESTART" : "GESTOPT");
  BT.print("Status: ");
  BT.println(running ? "GESTART" : "GESTOPT");
}

void handleButton() {
  if (!buttonPressed) return;
  buttonPressed = false;
  updateState(!running);
}

void buttonISR() {
  static unsigned long lastInterruptTime = 0;
  unsigned long now = millis();
  if (now - lastInterruptTime > 600) {
    buttonPressed = true;
    lastInterruptTime = now;
  }
}

void parseBtCommand(char* command) {
  if (strlen(command) == 0) return;

  Serial.print("BT Command: "); Serial.println(command);
  BT.print("Command: "); BT.println(command);

  // Controleer eerst op commando's met een waarde (bv. kp1.2)
  if (strncmp(command, "kp", 2) == 0) {
    pid_settings.Kp = atof(command + 2);
    BT.print("Kp ingesteld op: "); BT.println(pid_settings.Kp);
    saveSettings();
    return;
  }
  if (strncmp(command, "kd", 2) == 0) {
    pid_settings.Kd = atof(command + 2);
    BT.print("Kd ingesteld op: "); BT.println(pid_settings.Kd);
    saveSettings();
    return;
  }
  if (strncmp(command, "ki", 2) == 0) {
    float value = atof(command + 2);
    if (value == 0) { integral = 0; }
    pid_settings.Ki = value;
    BT.print("Ki ingesteld op: "); BT.println(pid_settings.Ki);
    saveSettings();
    return;
  }
  if (strncmp(command, "cycle", 5) == 0) {
    pid_settings.cycleTime = (unsigned long)atof(command + 5);
    BT.print("CycleTime ingesteld op: "); BT.println(pid_settings.cycleTime);
    saveSettings();
    return;
  }
  if (strncmp(command, "speed", 5) == 0) {
    pid_settings.baseSpeed = (int)atof(command + 5);
    BT.print("BaseSpeed ingesteld op: "); BT.println(pid_settings.baseSpeed);
    saveSettings();
    return;
  }

  // Controleer daarna op commando's van één letter
  if (strlen(command) > 1) {
    BT.print("Onbekend commando: "); BT.println(command);
    return;
  }

  switch (command[0]) {
    case 'm': // Motor test
      updateState(false); // Stop de robot eerst
      BT.println("--- Motor Test ---");
      
      // 1. Beide motoren vooruit
      BT.println("Beide motoren vooruit (3s)...");
      analogWrite(MotorLeft1, 150);
      digitalWrite(MotorLeft2, LOW);
      analogWrite(MotorRight1, 150);
      digitalWrite(MotorRight2, LOW);
      delay(3000);
      stopMotors();
      delay(500);

      // 2. Alleen links vooruit
      BT.println("Linker motor vooruit (3s)...");
      analogWrite(MotorLeft1, 150);
      digitalWrite(MotorLeft2, LOW);
      delay(3000);
      stopMotors();
      delay(500);

      // 3. Alleen rechts vooruit
      BT.println("Rechter motor vooruit (3s)...");
      analogWrite(MotorRight1, 150);
      digitalWrite(MotorRight2, LOW);
      delay(3000);
      stopMotors();

      BT.println("--- Test Voltooid ---");
      break;
    case 't':
      updateState(true);
      running = true;
      break;
    case 'o':
      updateState(false);
      running = false;
      break;
    case 'c':
      Serial.println(">>> START KALIBRATIE VIA BLUETOOTH <<<");
      BT.println(">>> START KALIBRATIE VIA BLUETOOTH <<<");
      calibrate();
      calibrated = true;
      break;
    case 'd':
      debug_output = !debug_output; // Wissel de status
      BT.print("Debug output "); BT.println(debug_output ? "AAN" : "UIT");
      break;
    case 'v':
      BT.println("--- Huidige Instellingen ---");
      BT.print("Kp: "); BT.println(pid_settings.Kp, 4);
      BT.print("Ki: "); BT.println(pid_settings.Ki, 4);
      BT.print("Kd: "); BT.println(pid_settings.Kd, 4);
      BT.print("BaseSpeed: "); BT.println(pid_settings.baseSpeed);
      BT.print("CycleTime (ms): "); BT.println(pid_settings.cycleTime);
      BT.println("--------------------------");
      break;
    case 'h':
      BT.println("--- Commando Menu ---");
      BT.println("t         - Start robot");
      BT.println("o         - Stop robot");
      BT.println("c         - Start kalibratie");
      BT.println("d         - Toggle debug output");
      BT.println("kp<waarde> - Set Kp (bv. kp0.8)");
      BT.println("ki<waarde> - Set Ki (bv. ki0)");
      BT.println("kd<waarde> - Set Kd (bv. kd4.5)");
      BT.println("speed<waarde> - Set baseSpeed (bv. speed150)");
      BT.println("cycle<waarde> - Set cycleTime in ms (bv. cycle30)");
      BT.println("v         - Toon instellingen");
      BT.println("m         - Test motoren");
      BT.println("h         - Toon dit menu");
      BT.println("---------------------");
      break;
    default:
      BT.println("Onbekend commando");
      break;
  }
}

void handleBluetooth() {
  while (BT.available()) {
    char c = BT.read();
    if (c == '\n' || c == '\r') { // Einde van commando
      bt_buffer[bt_buf_pos] = '\0'; // Maak er een geldige string van
      parseBtCommand(bt_buffer);
      bt_buf_pos = 0; // Reset de buffer voor het volgende commando
    } else if (bt_buf_pos < sizeof(bt_buffer) - 1) {
      bt_buffer[bt_buf_pos++] = c;
    }
  }
}

void handleSerialToBT() {
  if (Serial.available()) {
    BT.write(Serial.read());
  }
}

// ===================
// Setup
// ===================
void setup() {
  pinMode(buttonPin, INPUT_PULLUP);
  pinMode(ledPin, OUTPUT);
  attachInterrupt(digitalPinToInterrupt(buttonPin), buttonISR, FALLING);
  Serial.begin(9600);
  BT.begin(9600);
  while (!Serial);

  debug_output = false;

  // Motoren initialiseren
  pinMode(MotorLeft1, OUTPUT);
  pinMode(MotorLeft2, OUTPUT);
  pinMode(MotorRight1, OUTPUT);
  pinMode(MotorRight2, OUTPUT);
  pinMode(SleepPin, OUTPUT);
  digitalWrite(SleepPin, HIGH); // Activeer de DRV8833 driver

  loadSettings();
  Serial.println("Instellingen geladen uit EEPROM.");
  BT.println("Instellingen geladen uit EEPROM.");

  calibrated = loadCalibration();
  if (calibrated) {
    Serial.println("Kalibratie geladen uit EEPROM.");
    BT.println("Kalibratie geladen uit EEPROM.");
  } else {
    Serial.println("Geen geldige kalibratie gevonden.");
    BT.println("Geen geldige kalibratie gevonden.");
  }

  Serial.println("\nSysteem klaar. Stuur 'h' voor een menu met commando's.");
  BT.println("\nSysteem klaar. Stuur 'h' voor een menu met commando's.");
}

// ===================
// Loop
// ===================
void loop() {
  handleButton();
  handleBluetooth();
  handleSerialToBT();
  
  // Als de robot niet draait, doe verder niets in de loop.
  if (!running) { // Als de robot gestopt is
    stopMotors();   // Zorg ervoor dat de motoren altijd uit zijn.
    integral = 0;   // Reset de integraalterm om opbouw te voorkomen.
    lastError = 0;  // Reset de laatste fout.
    delay(10);      // Kleine pauze om de loop niet te snel te laten spinnen.
    return;         // Stop hier en ga niet verder met de PID-logica.
  }

  // --- Start van de getimede cyclus ---
  unsigned long cycleStartTimestamp = millis();

  uint16_t raw[NUM_SENSORS];
  float position = calcLinePosition(raw);

  // Controleer op een voltooide ronde
  checkLap(raw);

  // PID Berekening
  // De fout is het verschil tussen de huidige positie en het doel (midden = 3.5)
  float error = position - 3.5;

  // Schaal de fout van [-3.5, 3.5] naar een groter bereik, bijv. [-35, 35]
  error = error * 10.0;

  // Integrale term (voor nu simpel, kan later verfijnd worden)
  integral += error;

  // Derivatieve term
  float derivative = error - lastError;

  // Bereken de stuur-output
  float output = pid_settings.Kp * error + pid_settings.Ki * integral + pid_settings.Kd * derivative;

  lastError = error; // Onthoud de fout voor de volgende cyclus

  // Bereken de theoretische snelheid voor elke motor
  int leftSpeed = pid_settings.baseSpeed + output;
  int rightSpeed = pid_settings.baseSpeed - output;

  // Beperk de snelheid tot het PWM-bereik (-255 tot 255)
  leftSpeed = constrain(leftSpeed, -255, 255);
  rightSpeed = constrain(rightSpeed, -255, 255);

  // Stuur de motoren aan
  if (leftSpeed >= 0) {
    analogWrite(MotorLeft1, leftSpeed);
    digitalWrite(MotorLeft2, LOW);
  } else {
    digitalWrite(MotorLeft1, LOW);
    analogWrite(MotorLeft2, -leftSpeed);
  }

  if (rightSpeed >= 0) {
    analogWrite(MotorRight1, rightSpeed);
    digitalWrite(MotorRight2, LOW);
  } else {
    digitalWrite(MotorRight1, LOW);
    analogWrite(MotorRight2, -rightSpeed);
  }

  if (debug_output) {
    // Compacte output voor de Bluetooth-terminal
    showLineASCII(position);
    BT.print("  E:"); BT.print(error, 2);
    BT.print(", L:"); BT.print(leftSpeed);
    BT.print(", R:"); BT.println(rightSpeed);
  }

  // --- Einde van de getimede cyclus ---
  unsigned long executionTime = millis() - cycleStartTimestamp;
  if (executionTime < pid_settings.cycleTime) {
    delay(pid_settings.cycleTime - executionTime);
  }
}